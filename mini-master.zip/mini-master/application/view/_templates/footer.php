
    <script>
        var url = "<?php echo URL; ?>";
    </script>

    <script src="<?php echo URL; ?>mini-master/mini-master.js"></script>

</body>
</html>
